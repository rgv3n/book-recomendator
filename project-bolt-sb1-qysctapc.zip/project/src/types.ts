export interface Book {
  title: string;
  author: string;
  description: string;
  imageUrl: string;
  review: string;
}

export interface BookRecommendation {
  mood: string;
  books: Book[];
}