import React, { useState } from 'react';
import { HfInference } from '@huggingface/inference';
import { Book, BookRecommendation } from './types';
import { BookCard } from './components/BookCard';
import { BookOpen, Search, Loader2 } from 'lucide-react';

const hf = new HfInference("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");

function App() {
  const [mood, setMood] = useState('');
  const [loading, setLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<Book[]>([]);
  const [error, setError] = useState<string | null>(null);

  const getRecommendations = async () => {
    setLoading(true);
    setError(null);
    try {
      const prompt = `Como experto bibliotecario, basado en el estado de ánimo "${mood}", recomiéndame 3 libros. Responde SOLO en formato JSON, sin texto adicional, siguiendo exactamente esta estructura:
{
  "books": [
    {
      "title": "El título del libro",
      "author": "Nombre del autor",
      "description": "Una breve descripción del libro y por qué se relaciona con el estado de ánimo",
      "imageUrl": "https://source.unsplash.com/featured/?book,${encodeURIComponent(mood)}",
      "review": "Una breve reseña personal del libro"
    }
  ]
}`;

      const response = await hf.textGeneration({
        model: "mistralai/Mixtral-8x7B-Instruct-v0.1",
        inputs: prompt,
        parameters: {
          max_new_tokens: 1024,
          temperature: 0.7,
          return_full_text: false,
        },
      });

      // Find the first occurrence of '{' and the last occurrence of '}'
      const jsonStart = response.generated_text.indexOf('{');
      const jsonEnd = response.generated_text.lastIndexOf('}') + 1;
      
      if (jsonStart === -1 || jsonEnd === 0) {
        throw new Error('No se pudo encontrar un JSON válido en la respuesta');
      }

      const jsonStr = response.generated_text.slice(jsonStart, jsonEnd);
      const data = JSON.parse(jsonStr) as BookRecommendation;

      if (!data.books || !Array.isArray(data.books)) {
        throw new Error('El formato de la respuesta no es válido');
      }

      setRecommendations(data.books);
    } catch (error) {
      console.error('Error al obtener recomendaciones:', error);
      setError('Lo siento, hubo un error al obtener las recomendaciones. Por favor, intenta de nuevo.');
      setRecommendations([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 to-indigo-100">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <BookOpen className="w-16 h-16 mx-auto text-indigo-600 mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Recomendador de Libros
          </h1>
          <p className="text-lg text-gray-600">
            Descubre libros perfectos para tu estado de ánimo actual
          </p>
        </div>

        <div className="max-w-xl mx-auto mb-12">
          <div className="flex gap-4">
            <input
              type="text"
              value={mood}
              onChange={(e) => setMood(e.target.value)}
              placeholder="¿Cómo te sientes hoy? (ej: feliz, nostálgico, inspirado...)"
              className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              onClick={getRecommendations}
              disabled={loading || !mood}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
              Buscar
            </button>
          </div>
          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600">
              {error}
            </div>
          )}
        </div>

        {recommendations.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {recommendations.map((book, index) => (
              <BookCard key={index} book={book} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;